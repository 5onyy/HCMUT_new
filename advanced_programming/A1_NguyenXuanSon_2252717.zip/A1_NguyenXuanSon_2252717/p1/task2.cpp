#include<bits/stdc++.h>
using namespace std;

int main(){
      int a, b;
      cout << "Please input two numbers (a) (b): \n";
      cin >> a >> b;
      cout << "The sum of two numbers is: "<< a << " + " << b << " = " << (a + b) << '\n';
      cout << "The subtraction of two numbers is: "<< a << " - " << b << " = " << (a - b) << '\n';
      cout << "The division of two numbers is: "<< a << " / " << b << " = "<< (a / b) << '\n';
      cout << "The modulus of two numbers is: "<< a << " % " << b << " = " << (a % b) << '\n';
      return 0;
}