#include<bits/stdc++.h>
using namespace std;

int main(){
      int a, b, c;
      cout << "Please input three numbers (a) (b) (c): \n";
      cin >> a >> b >> c;
      cout << "The average of three numbers is: "<< (double) (a + b + c) / 3 << '\n';
      return 0;
}