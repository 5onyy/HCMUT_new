#include <bits/stdc++.h>
using namespace std;
int main(){
      int x, y;
      cout << "This program is used to calculate x% percentage of y \nPlease input two numbers (x) and (y): \n";
      cin >> x >> y;
      cout << x << "% of number " << y << " is: " << (double) x * y / 100 << '\n';
}